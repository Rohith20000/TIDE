package utilities;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class AutomationTestReport {
	public static WebDriver driver;
	public static ExtentReports extent;
	public static ExtentTest logger;
	
	
	public void report() {
		ExtentSparkReporter report = new ExtentSparkReporter("./TestReport.html");

		 extent = new ExtentReports();
		
		extent.attachReporter(report);
		
		logger=extent.createTest("logintest");

}
	
	public void teardown(ITestResult result) throws IOException {
		if (result.getStatus()==ITestResult.FAILURE) {
			String temp = ScreenShot.takescreenshot(driver);
			 logger.fail(result.getThrowable().getMessage(),MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		}
		extent.flush();
		driver.quit();

	}
}
