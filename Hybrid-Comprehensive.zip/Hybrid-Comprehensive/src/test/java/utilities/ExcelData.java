package utilities;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class ExcelData {
	
	@DataProvider (name = "TestData")
		public String[][] getData() throws Exception{
			File excelfile=new File("C:\\Users\\M1087956\\eclipse-workspace\\selenium\\Hybrid-Comprehensive\\src\\test\\resources\\test.xlsx");
		System.out.println(excelfile.exists());
		FileInputStream fis=new FileInputStream(excelfile);
		XSSFWorkbook workbook=new XSSFWorkbook(fis);
		XSSFSheet sheet= workbook.getSheet("Sheet1");
		
		int noofrows = sheet.getPhysicalNumberOfRows();
		int noofcolumns = sheet.getRow(0).getLastCellNum();
		
		String[][] data=new String[noofrows-1][noofcolumns];
		for (int i = 0; i < noofrows-1; i++) {
			for (int j = 0; j < noofcolumns; j++) {
				DataFormatter df=new DataFormatter();
				data[i][j]= df.formatCellValue(sheet.getRow(i+1).getCell(j));
				
			}
		}
		
		workbook.close();
		fis.close();
		
		//for (String[] dataArr : data) {
		//	System.out.println(Arrays.toString(dataArr));
		//}
		return data;
		
		
		
		
		
		}
}
