package runner;

import java.io.IOException;

import org.testng.annotations.Test;

import baseclass.BaseClass;
import uistore.LanPojo;
import uistore.LivechatPojo;
import uistore.LoadsofhopePojo;
import uistore.LoginPojo;
import uistore.OurcommitmentPojo;
import uistore.SearchPojo;
import uistore.ShopProductPojo;
import uistore.ShopnowPojo;
import uistore.WashPojo;
import uistore.WhatsnewPojo;
import utilities.Log4j;

public class Runner extends BaseClass {

	
	@Test
	private void TC1() throws IOException, InterruptedException {

		initializebrowser();
		Log4j.loginfo("Browser launched");
		LoginPojo p = new LoginPojo();
		Thread.sleep(8000);
		click(p.getClkclose());
		click(p.getClickregister());
		Log4j.loginfo("In the Register page");
		click(p.getClksignup());

		windowshandle();

		fill(p.getFillname(), "rohith");
		fill(p.getFillemail(), "rohith@gmail.com");
		fill(p.getFillpassword(), "Rohith$2000");
		click(p.getClickCA());
		Log4j.loginfo("Created the Account");

	}

	@Test
	private void TC2() throws IOException, InterruptedException {
		initializebrowser();
		Log4j.loginfo("Browser launched");
		SearchPojo p = new SearchPojo();
		Thread.sleep(8000);
		click(p.getClkclose());
		Log4j.loginfo("Searching some product");
		fill(p.getFillsearch(), "tide ultra OXI");
		click(p.getClksearch());
		Log4j.loginfo("Reached the product page");
		

	}

	@Test
	private void TC3() throws IOException, InterruptedException {
		initializebrowser();
		Log4j.loginfo("Browser launched");
		ShopProductPojo p = new ShopProductPojo();
		Thread.sleep(5000);
		click(p.getClkclose());
		movetoelement(p.getGoshopproduct());
		Log4j.loginfo("checking the products under ShopProduct");

	}

	@Test
	private void TC4() throws IOException, InterruptedException {
		initializebrowser();
		Log4j.loginfo("Browser launched");
		WashPojo p = new WashPojo();
		Thread.sleep(5000);
		click(p.getClkclose());
		click(p.getGohowtowash());
		Log4j.loginfo("checking how to wash product field");

	}

	@Test
	private void TC5() throws IOException, InterruptedException {
		initializebrowser();
		Log4j.loginfo("Browser launched");
		OurcommitmentPojo p = new OurcommitmentPojo();
		Thread.sleep(7000);
		click(p.getClkclose());
		click(p.getClickOC());
		Log4j.loginfo("checking OurCommitmentpage");
		click(p.getClickAmericaNumOne());
		Log4j.loginfo("should be in America#1 page");

	}

	@Test
	private void TC6() throws IOException, InterruptedException {
		initializebrowser();
		Log4j.loginfo("Browser launched");
		WhatsnewPojo p = new WhatsnewPojo();
		Thread.sleep(7000);
		click(p.getClkclose());
		click(p.getClickWhatsnew());
		Log4j.loginfo("Whats New field");

	}

	@Test
	private void TC7() throws IOException, InterruptedException {
		initializebrowser();
		Log4j.loginfo("Browser launched");
		LivechatPojo p = new LivechatPojo();
		Thread.sleep(7000);
		click(p.getClkclose());
		click(p.getClklivechat());
		Log4j.loginfo("LiveChat field");

	}

	@Test
	private void TC8() throws IOException, InterruptedException {
		initializebrowser();
		Log4j.loginfo("Browser launched");
		LanPojo p = new LanPojo();
		Thread.sleep(5000);
		click(p.getClkclose());
		click(p.getClkLan());
		click(p.getClkCanadaFre());
		Log4j.loginfo("Checking Language field");

	}

	@Test
	private void TC9() throws IOException, InterruptedException {
		initializebrowser();
		Log4j.loginfo("Browser launched");
		LoadsofhopePojo p = new LoadsofhopePojo();
		Thread.sleep(5000);
		click(p.getClkclose());
		click(p.getClkReadmore());
		Log4j.loginfo("Loads of hope field");

	}

	@Test
	private void TC10() throws IOException, InterruptedException {
		initializebrowser();
		Log4j.loginfo("Browser launched");
		ShopnowPojo p = new ShopnowPojo();
		Thread.sleep(8000);
		click(p.getClkclose());
		click(p.getClkliquid());
		Log4j.loginfo("clicking Liquid field");
		Thread.sleep(5000);
		click(p.getClk());
		Log4j.loginfo("Reached Retailers page");

	}
}
