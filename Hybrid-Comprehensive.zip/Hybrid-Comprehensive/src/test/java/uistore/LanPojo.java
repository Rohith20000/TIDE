package uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclass.BaseClass;

public class LanPojo extends BaseClass{

	public LanPojo() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[@class='lilo3746-close-link lilo3746-close-icon']")
	private WebElement clkclose;
	
	@FindBy(xpath="//button[text()='US - English']")
	private WebElement clkLan;

	
	@FindBy(xpath="//a[@href='https://tide.ca/fr-ca']")
	private WebElement clkCanadaFre;
	
	
	public WebElement getClkCanadaFre() {
		return clkCanadaFre;
	}

	public void setClkCanadaFre(WebElement clkCanadaFre) {
		this.clkCanadaFre = clkCanadaFre;
	}

	public WebElement getClkclose() {
		return clkclose;
	}

	public void setClkclose(WebElement clkclose) {
		this.clkclose = clkclose;
	}

	public WebElement getClkLan() {
		return clkLan;
	}

	public void setClkLan(WebElement clkLan) {
		this.clkLan = clkLan;
	}
}
