package uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclass.BaseClass;

public class WhatsnewPojo extends BaseClass{

	public WhatsnewPojo() {
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "(//a[@class='menu-item-title event_menu_click '])[4]")
	private WebElement clickWhatsnew;
	
	@FindBy(xpath="//a[@class='lilo3746-close-link lilo3746-close-icon']")
	private WebElement clkclose;

	public WebElement getClickWhatsnew() {
		return clickWhatsnew;
	}

	public void setClickWhatsnew(WebElement clickWhatsnew) {
		this.clickWhatsnew = clickWhatsnew;
	}

	public WebElement getClkclose() {
		return clkclose;
	}

	public void setClkclose(WebElement clkclose) {
		this.clkclose = clkclose;
	}
}
