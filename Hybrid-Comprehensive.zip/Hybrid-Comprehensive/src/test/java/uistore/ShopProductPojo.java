package uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclass.BaseClass;

public class ShopProductPojo extends BaseClass {

	public ShopProductPojo() {
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "(//a[@class='menu-item-title event_menu_click '])[1]")
	private WebElement goshopproduct;
	
	@FindBy(xpath="//a[@class='lilo3746-close-link lilo3746-close-icon']")
	private WebElement clkclose;
	
	
	
	
	public WebElement getClkclose() {
		return clkclose;
	}
	public void setClkclose(WebElement clkclose) {
		this.clkclose = clkclose;
	}
	public WebElement getGoshopproduct() {
		return goshopproduct;
	}
	public void setGoshopproduct(WebElement goshopproduct) {
		this.goshopproduct = goshopproduct;
	}
}
