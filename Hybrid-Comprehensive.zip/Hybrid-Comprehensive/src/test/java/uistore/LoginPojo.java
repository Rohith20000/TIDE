package uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclass.BaseClass;

public class LoginPojo extends BaseClass{

	public LoginPojo() {
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//span[@class='login-register']")
	private WebElement clickregister;
	
	@FindBy(xpath="//a[@class='event_internal_link']")
	private WebElement clksignup;
	
	@FindBy(xpath="//a[@class='lilo3746-close-link lilo3746-close-icon']")
	private WebElement clkclose;
	
	@FindBy(name="firstName")
	private WebElement fillname;
	
	@FindBy(id="email")
	private WebElement fillemail;
	
	@FindBy(id="password")
	private WebElement fillpassword;
	
	@FindBy(xpath = "//input[@type='submit']")
	private WebElement clickCA;
	
	

	public WebElement getClickCA() {
		return clickCA;
	}

	public void setClickCA(WebElement clickCA) {
		this.clickCA = clickCA;
	}

	public WebElement getFillpassword() {
		return fillpassword;
	}

	public void setFillpassword(WebElement fillpassword) {
		this.fillpassword = fillpassword;
	}

	public WebElement getFillemail() {
		return fillemail;
	}

	public void setFillemail(WebElement fillemail) {
		this.fillemail = fillemail;
	}

	public WebElement getFillname() {
		return fillname;
	}

	public void setFillname(WebElement fillname) {
		this.fillname = fillname;
	}

	public WebElement getClkclose() {
		return clkclose;
	}

	public void setClkclose(WebElement clkclose) {
		this.clkclose = clkclose;
	}

	public WebElement getClickregister() {
		return clickregister;
	}

	public void setClickregister(WebElement clickregister) {
		this.clickregister = clickregister;
	}

	public WebElement getClksignup() {
		return clksignup;
	}

	public void setClksignup(WebElement clksignup) {
		this.clksignup = clksignup;
	}
}
