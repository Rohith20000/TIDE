package uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclass.BaseClass;

public class WashPojo extends BaseClass{

	public WashPojo() {
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "(//a[@class='menu-item-title event_menu_click '])[3]")
	private WebElement gohowtowash;
	
	public WebElement getGohowtowash() {
		return gohowtowash;
	}

	public void setGohowtowash(WebElement gohowtowash) {
		this.gohowtowash = gohowtowash;
	}

	public WebElement getClkclose() {
		return clkclose;
	}

	public void setClkclose(WebElement clkclose) {
		this.clkclose = clkclose;
	}
	@FindBy(xpath="//a[@class='lilo3746-close-link lilo3746-close-icon']")
	private WebElement clkclose;
}
