package uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclass.BaseClass;

public class OurcommitmentPojo extends BaseClass {

	public OurcommitmentPojo() {
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "(//a[@class='menu-item-title event_menu_click '])[2]")
	private WebElement clickOC;
	
	public WebElement getClickOC() {
		return clickOC;
	}

	public void setClickOC(WebElement clickOC) {
		this.clickOC = clickOC;
	}

	public WebElement getClkclose() {
		return clkclose;
	}

	public void setClkclose(WebElement clkclose) {
		this.clkclose = clkclose;
	}
	@FindBy(xpath="//a[@class='lilo3746-close-link lilo3746-close-icon']")
	private WebElement clkclose;

	@FindBy(xpath = "(//a[@class='button-link event_button_click secondary'])[5]")
	private WebElement clickAmericaNumOne;

	public WebElement getClickAmericaNumOne() {
		return clickAmericaNumOne;
	}

	public void setClickAmericaNumOne(WebElement clickAmericaNumOne) {
		this.clickAmericaNumOne = clickAmericaNumOne;
	}
	
}
