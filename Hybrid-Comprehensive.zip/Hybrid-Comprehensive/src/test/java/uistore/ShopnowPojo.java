package uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclass.BaseClass;

public class ShopnowPojo extends BaseClass{

	
	public ShopnowPojo() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[@class='lilo3746-close-link lilo3746-close-icon']")
	private WebElement clkclose;
	
	@FindBy(xpath="(//span[text()='Liquid'])[2]")
	private WebElement clkliquid;
	
	@FindBy(xpath="(//span[@class='ps-button-label'])[3]")
	private WebElement clk;
	

	public WebElement getClk() {
		return clk;
	}

	public void setClk(WebElement clk) {
		this.clk = clk;
	}

	public WebElement getClkclose() {
		return clkclose;
	}

	public void setClkclose(WebElement clkclose) {
		this.clkclose = clkclose;
	}

	public WebElement getClkliquid() {
		return clkliquid;
	}

	public void setClkliquid(WebElement clkliquid) {
		this.clkliquid = clkliquid;
	}


}
