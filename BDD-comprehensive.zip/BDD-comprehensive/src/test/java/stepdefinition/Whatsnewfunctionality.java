package stepdefinition;

import baseclass.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uistore.WhatsnewPojo;
import utilities.Log4j;

public class Whatsnewfunctionality extends BaseClass {
	

	@When("User should click the What's New link")
	public void user_should_click_the_what_s_new_link() throws InterruptedException {
		WhatsnewPojo p = new WhatsnewPojo();
		Thread.sleep(7000);
		click(p.getClkclose());
		click(p.getClickWhatsnew());
		Log4j.loginfo("clicking Whats new link");
	}
	@Then("User should navigate to the What's new Page")
	public void user_should_navigate_to_the_what_s_new_page() {
		Log4j.loginfo("Whats New field");
		close();
	}



}
