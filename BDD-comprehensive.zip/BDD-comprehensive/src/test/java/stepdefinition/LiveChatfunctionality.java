package stepdefinition;

import baseclass.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uistore.LivechatPojo;
import utilities.Log4j;

public class LiveChatfunctionality extends BaseClass {

	@When("User should click LiveChat field")
	public void user_should_click_live_chat_field() throws InterruptedException {
		LivechatPojo p = new LivechatPojo();
		Thread.sleep(7000);
		click(p.getClkclose());
		click(p.getClklivechat());
		Log4j.loginfo("LiveChat field");
	}
	@Then("User should reach the Livechat page")
	public void user_should_reach_the_livechat_page() {
	   Log4j.loginfo("reached the live chat page");
		close();
	}


}
