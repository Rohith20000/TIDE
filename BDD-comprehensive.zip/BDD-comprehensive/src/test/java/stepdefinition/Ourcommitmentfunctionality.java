package stepdefinition;

import baseclass.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uistore.OurcommitmentPojo;
import utilities.Log4j;

public class Ourcommitmentfunctionality extends BaseClass{
	

	

	@When("User should take the curser to Our commitment")
	public void user_should_take_the_curser_to_our_commitment() throws InterruptedException {
		OurcommitmentPojo p = new OurcommitmentPojo();
		Thread.sleep(7000);
		click(p.getClkclose());
		click(p.getClickOC());
		Log4j.loginfo("checking OurCommitmentpage");
	}
	@When("user should click America's #{int} field")
	public void user_should_click_america_s_field(Integer int1) {
		OurcommitmentPojo p = new OurcommitmentPojo();
		click(p.getClickAmericaNumOne());
		Log4j.loginfo("should navigate to America #1 pgae");
	}
	@Then("User should see the valid page")
	public void user_should_see_the_valid_page() {
		Log4j.loginfo("should be in America#1 page");
		close();
	}






}
