package stepdefinition;

import baseclass.BaseClass;
import io.cucumber.java.en.When;
import uistore.SearchPojo;
import utilities.Log4j;

public class Searchfunctionality extends BaseClass{
	

	@When("User should enter product name in search field")
	public void user_should_enter_product_name_in_search_field() throws InterruptedException {
		SearchPojo p = new SearchPojo();
		Thread.sleep(8000);
		click(p.getClkclose());
		Log4j.loginfo("Searching some product");
		fill(p.getFillsearch(), "tide ultra OXI");
		Thread.sleep(3000);
		click(p.getClksearch());
	}



}
