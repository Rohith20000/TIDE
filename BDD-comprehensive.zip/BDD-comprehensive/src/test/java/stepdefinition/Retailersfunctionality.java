package stepdefinition;

import baseclass.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uistore.ShopnowPojo;
import utilities.Log4j;

public class Retailersfunctionality extends BaseClass{
	

	@When("User should click the Liquid link")
	public void user_should_click_the_liquid_link() throws InterruptedException {
		ShopnowPojo p = new ShopnowPojo();
		Thread.sleep(8000);
		click(p.getClkclose());
		click(p.getClkliquid());
	}
	@When("user should click Find Retailer")
	public void user_should_click_find_retailer() throws InterruptedException {
		ShopnowPojo p = new ShopnowPojo();
		Thread.sleep(5000);
		click(p.getClk());
		Log4j.loginfo("user should reach Retailers page");
	}
	@Then("User should navigate to the retailers page")
	public void user_should_navigate_to_the_retailers_page() {
		Log4j.loginfo("Reached Retailers page");
		close();
	}



}
