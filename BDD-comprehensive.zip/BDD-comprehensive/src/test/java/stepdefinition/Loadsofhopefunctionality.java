package stepdefinition;

import baseclass.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uistore.LoadsofhopePojo;
import utilities.Log4j;

public class Loadsofhopefunctionality extends BaseClass{
	
	@When("User should click the Load of Hope field")
	public void user_should_click_the_load_of_hope_field() throws InterruptedException {
		LoadsofhopePojo p = new LoadsofhopePojo();
		Thread.sleep(5000);
		click(p.getClkclose());
		click(p.getClkReadmore());
		Log4j.loginfo("Loads of hope field");
	}
	@Then("User should navigate valid page")
	public void user_should_navigate_valid_page() {
		Log4j.loginfo("Loads of hope field should be display");
		close();
	}



}
