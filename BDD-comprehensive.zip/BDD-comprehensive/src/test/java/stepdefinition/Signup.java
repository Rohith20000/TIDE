package stepdefinition;

import java.io.IOException;

import baseclass.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uistore.LoginPojo;
import utilities.Log4j;

public class Signup extends BaseClass{
	
	@Given("User is in Tide page")
	public void user_is_in_tide_page() throws IOException {
		initializebrowser();
		Log4j.loginfo("Browser launched");
	}
	@When("User should click register link and in register page user should click Signup")
	public void user_should_click_register_link_and_in_register_page_user_should_click_signup() throws InterruptedException {
		LoginPojo p = new LoginPojo();
		Thread.sleep(8000);
		click(p.getClkclose());
		click(p.getClickregister());
		Log4j.loginfo("In the Register page");
		click(p.getClksignup());
	}
	@When("User should enter valid Name,Email,password and click create account")
	public void user_should_enter_valid_name_email_password_and_click_create_account() {
		windowshandle();
   
		LoginPojo p = new LoginPojo();
		fill(p.getFillname(), "rohith");
		fill(p.getFillemail(), "rohith@gmail.com");
		fill(p.getFillpassword(), "Rohith$2000");
		click(p.getClickCA());
		Log4j.loginfo("Created the Account");
	}
	@Then("User should reach the valid page")
	public void user_should_reach_the_valid_page() {
	  
	  close();
	}



}
