package stepdefinition;

import baseclass.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uistore.WashPojo;
import utilities.Log4j;

public class HowtowashFunctionality extends BaseClass {
	

	@When("User should take the curser to How to wash")
	public void user_should_take_the_curser_to_how_to_wash() throws InterruptedException {
		WashPojo p = new WashPojo();
		Thread.sleep(7000);
		click(p.getClkclose());
		Thread.sleep(3000);
		click(p.getGohowtowash());
		Log4j.loginfo("checking how to wash product field");
	}
	@Then("User should see the details in the dropdown")
	public void user_should_see_the_details_in_the_dropdown() {
		Log4j.loginfo("showing the details in the DropDown");
		close();
	}



}
