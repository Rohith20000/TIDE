package stepdefinition;

import baseclass.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uistore.LanPojo;
import utilities.Log4j;

public class Languagefunctionality extends BaseClass{
	

	@When("User should change the language")
	public void user_should_change_the_language() throws InterruptedException {
		LanPojo p = new LanPojo();
		Thread.sleep(5000);
		click(p.getClkclose());
		click(p.getClkLan());
		click(p.getClkCanadaFre());
		Log4j.loginfo("Checking Language field");
	}
	@Then("User should reach selected language page")
	public void user_should_reach_selected_language_page() {
		Log4j.loginfo("reached Canada-french");
		close();
		
	}



}
