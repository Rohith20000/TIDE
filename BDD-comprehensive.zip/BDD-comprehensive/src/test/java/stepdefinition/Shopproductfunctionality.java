package stepdefinition;

import baseclass.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import uistore.ShopProductPojo;
import utilities.Log4j;

public class Shopproductfunctionality extends BaseClass {
	

	@When("User should take the curser")
	public void user_should_take_the_curser() throws InterruptedException {
		ShopProductPojo p = new ShopProductPojo();
		Thread.sleep(5000);
		click(p.getClkclose());
		Thread.sleep(3000);
		movetoelement(p.getGoshopproduct());
		 
	}
	@Then("User should see the products in the dropdown")
	public void user_should_see_the_products_in_the_dropdown() {
		Log4j.loginfo("checking the products under ShopProduct");
		close();
	}



}
