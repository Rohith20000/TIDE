package uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclass.BaseClass;

public class SearchPojo extends BaseClass{

	
	public SearchPojo() {
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath = "//input[@placeholder='Search']")
	private WebElement fillsearch;
	
	@FindBy(xpath="//a[@class='lilo3746-close-link lilo3746-close-icon']")
	private WebElement clkclose;
	
	@FindBy(xpath="//button[@type='submit']")
	private WebElement clksearch;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public WebElement getClkclose() {
		return clkclose;
	}
	public void setClkclose(WebElement clkclose) {
		this.clkclose = clkclose;
	}
	public WebElement getClksearch() {
		return clksearch;
	}
	public void setClksearch(WebElement clksearch) {
		this.clksearch = clksearch;
	}
	public WebElement getFillsearch() {
		return fillsearch;
	}
	public void setFillsearch(WebElement fillsearch) {
		this.fillsearch = fillsearch;
	}
	
}
