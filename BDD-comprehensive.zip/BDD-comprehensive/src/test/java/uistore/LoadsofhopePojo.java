package uistore;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseclass.BaseClass;

public class LoadsofhopePojo extends BaseClass{

	public LoadsofhopePojo() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[@class='lilo3746-close-link lilo3746-close-icon']")
	private WebElement clkclose;
	
	@FindBy(xpath="(//a[text()='Read More'])[2]")
	private WebElement clkReadmore;

	public WebElement getClkclose() {
		return clkclose;
	}

	public void setClkclose(WebElement clkclose) {
		this.clkclose = clkclose;
	}

	public WebElement getClkReadmore() {
		return clkReadmore;
	}

	public void setClkReadmore(WebElement clkReadmore) {
		this.clkReadmore = clkReadmore;
	}
}
