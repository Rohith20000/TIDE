package baseclass;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import utilities.ScreenShot;

public class BaseClass {

	public static Actions a;
	public static Properties pro;
	public static WebDriver driver;
	public static ExtentReports extent;
	public static ExtentTest logger;

	public static void initializebrowser() throws IOException {

		FileInputStream fis = new FileInputStream(
				"C:\\Users\\M1087956\\eclipse-workspace\\selenium\\BDD-comprehensive\\src\\test\\resources\\config.properties");

		pro = new Properties();

		pro.load(fis);

		String broswer = pro.getProperty("browser");

		String driverlocation = pro.getProperty("path");

		if (broswer.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", driverlocation);
			driver = new ChromeDriver();
		} else if (broswer.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", driverlocation);
			driver = new FirefoxDriver();
		}

		driver.get(pro.getProperty("url"));

	}

	public static void impliwait(int num) {
		driver.manage().timeouts().implicitlyWait(num, TimeUnit.SECONDS);

	}

	public static void click(WebElement string) {
		string.click();

	}

	public static void close() {
		driver.close();

	}

	public static void fill(WebElement element, String usertext) {
		element.sendKeys(usertext);

	}

	public static void movetoelement(WebElement element) {
		a = new Actions(driver);
		a.moveToElement(element).perform();

	}

	public static void maxpage() {
		driver.manage().window().maximize();

	}

	public static void gettitle() {
		String title = driver.getTitle();
		System.out.println(title);

	}

	public static void windowshandle() {

		String parentid = driver.getWindowHandle();
		System.out.println(parentid);

		Set<String> allwindow = driver.getWindowHandles();

		for (String eachId : allwindow) {
			if (!eachId.equals(parentid)) {
				driver.switchTo().window(eachId);
			}
		}

	}
	
	
	public void report() {
		ExtentSparkReporter report = new ExtentSparkReporter("./TestReport.html");

		 extent = new ExtentReports();
		
		extent.attachReporter(report);
		
		logger=extent.createTest("logintest");

}
	
	public void teardown(ITestResult result) throws IOException {
		if (result.getStatus()==ITestResult.FAILURE) {
			String temp = ScreenShot.takescreenshot(driver);
			 logger.fail(result.getThrowable().getMessage(),MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
		}
		extent.flush();
		driver.quit();

	}
}
