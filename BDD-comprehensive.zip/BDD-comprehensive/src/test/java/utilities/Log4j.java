package utilities;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Log4j {
	public static Logger log= LogManager.getLogger(Log4j.class);


	public static void loginfo(String info) {
         log.info(info);
	}
	public static void logwarn(String warn) {
		log.warn(warn);

	}
	public static void logerror(String error) {
		log.error(error);	
}
	public static  void logfatal(String fatal) {
		log.fatal(fatal);
}
}
