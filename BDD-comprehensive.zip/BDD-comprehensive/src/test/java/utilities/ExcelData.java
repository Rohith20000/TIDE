package utilities;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelData {

    XSSFWorkbook workbook;
    XSSFSheet sheet;

	public ExcelData(String path) {
		try {
			File excelfile = new File(path);
			FileInputStream fis = new FileInputStream(excelfile);
			workbook = new XSSFWorkbook(fis);

		} catch (Exception e) {
			e.printStackTrace();
		} 

	}

	public String getdata(int getsheet,int row,int cell) {
		
		sheet=workbook.getSheetAt(getsheet);
		String scv = sheet.getRow(row).getCell(cell).getStringCellValue();
		return scv;

	}
}
